package example;

public class VariableExample {

	
	//global variable  (within class, and out from function)
	int x; //instance varible
	static int y;  //static variable 
	
	public static void main(String[] args) {

		int a,b,c; //local variable 
		a =44;
		b =55;
		c =a+b;
		System.out.println("Hi, this is test program");
		System.out.println("sum of two values "+c);
		
		y =100; //store data on global varibale
		y =200;
		add(); //call to function - add()
				
	}

	public static void add() {
		 
		int d=1; //is local varible
		System.out.println(d);  
		System.out.println(y);

		//instance variable
		VariableExample o1 = new VariableExample();
		o1.x =21;
		
		VariableExample o2 = new VariableExample();
		o2.x =421;
		
		System.out.println(o1.x);
		System.out.println(o2.x);
		
		
		
	}
}

package example;

import java.util.Scanner;

/*
 * 1. import 
 * 2. create object of Scanner
 * 3. read : nextInt()
 */
public class InputExample {

	public static void main(String[] args) {

		//create object of Scanner
		
		Scanner s = new Scanner(System.in);  //Scanner is inbuilt class 
		float l,b,a,p;
		
		System.out.println("enter data for l");
		l = s.nextFloat(); //nextInt() is function to read from user
		System.out.println("enter data for b");
		 
	b = s.nextFloat(); //nextInt() is function to read from user 
		a = (float)l*b;//area of rectangle
		p = (float)2*(l+b);
		
		System.out.println(" Area of a rectangle "+a);	
	    System.out.println(" Perimeter of rectangle "+p);
		
		//double x = (float) 22/7;
		//System.out.println(x);
		
	}

}

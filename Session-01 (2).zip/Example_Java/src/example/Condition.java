package example;

import java.util.Scanner;

public class Condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		int a,b,c;
		
		System.out.println("enter data ");
		a = s.nextInt();
		
		System.out.println("enter data ");
		b = s.nextInt();
		
		if(a>b) {
			
			System.out.println("a is gt");
		}else {
			
			System.out.println("b is gt");
		}
		
	}

}

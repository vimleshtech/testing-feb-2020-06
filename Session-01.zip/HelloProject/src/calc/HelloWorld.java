package calc;

import java.util.Scanner;

public class HelloWorld 
{

	int a;
	static int b;
	
	public static void main(String[] a) {
		
		HelloWorld o1 = new HelloWorld();
		HelloWorld o2 = new HelloWorld();
		o1.a=1;
		o1.b =1;
		//System.out.println(a[0]);
		
		
		o2.a=10;
		o2.b =10;
		
		System.out.println(o1.a); // 1
		System.out.println(o1.b); //10
		System.out.println(o2.a); //10
		System.out.println(o2.b); //10
		
		/*input from user*/
		
		Scanner sc = new Scanner(System.in);
		int n1,n2,n3;
		String name;
		
		System.out.println("enter 3 values");
		n1 = sc.nextInt();
		n2 = sc.nextInt();		
		n3 = sc.nextInt();
		
		System.out.println("enter name ");
		name = sc.next();//this is
		
		if(n1> n2  && n1> n3) {
			System.out.println(" n1 is gt");
		}else if(n2> n1 && n2> n3) {
			System.out.println("n2 is is gt");
			
		}else {
			System.out.println("n3 is gt");
		}
		
		
		System.out.println("name is "+name);
		
		
		
	}

}

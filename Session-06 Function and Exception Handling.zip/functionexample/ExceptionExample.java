package functionexample;

import java.util.Scanner;

import javax.sound.midi.Soundbank;

public class ExceptionExample {

	public static void main(String[] args) {
	
		int a,b,c;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter data for a, and b");
		a = sc.nextInt();
		
		System.out.println("enter data for a, and b");
		b = sc.nextInt();
		
		try {
			//division
			
			if(b<0) {
				Exception v = new Exception("divisor cannot be less than 0");
				throw v; //just like go to statement , will move the code Exception block
			}
			
			c =a/b;
			System.out.println("division of two values "+c);
			
		}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("arithmetic error!");
		}
		catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		catch (Exception e) { //Exception is inbuilt class which can receive any type of error, e is a variable
			// TODO: handle exception
			System.out.println(e.toString()); //print the system error 
		}
		finally { //is optional block
			System.out.println("end of block");
			//logout 
		}
		//addition of two values
		c =a+b;
		System.out.println("addition of two values "+c);
		
	}

}

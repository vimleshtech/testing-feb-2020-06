package functionexample;

import java.util.Scanner;

public class FunctionExample {

	public static void main(String[] args) {
		
		//call to function 
		welcome();
		welcome();
				
		int a,b,c;
		a = getData();
		b = getData();
		
		c = a+b;
		System.out.println("sum of two values "+c);
		
		//call to function with argument
		sum(11, 44, 66);
		sum(1121, 444, 660);
		
		
		//
		int o = sub(5655,44);
		System.out.println(o);
		
		//call to recussive function 
		int f= fact(5);
		System.out.println("factorial is "+f);
		
	}
	//no argument no return function  
	public static void welcome() {
		
		System.out.println("welcome to function world!!!");
		System.out.println("this program contains i. welcome ii. getdata iii. sum iv. sub functions");		
	}

	//no argument with return
	public static int getData() {
		
		int n;		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		n = sc.nextInt();
				
		return n;
	}
	
	//argument with no return 
	public static void sum(int a, int b, int c) {
		int d =a+b+c;
		System.out.println("sum of three numebrs "+c);
				
		
	}
	//argument with return
	public static int sub(int a, int b) {
		return a-b;
	}

	//Recussive function 
	public static int fact(int n) {
		
		if(n==1) {
			return n;
		}else {			
			return n*fact(n-1);//5 * 4 *3 *2 *1
		}
	}
}

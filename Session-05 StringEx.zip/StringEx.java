package stringexample;

import java.util.Scanner;

public class StringEx {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("enter string data ");
		String name = sc.nextLine();

		//convert to upper case 
		System.out.println(name.toUpperCase());
		//convert to lower case
		System.out.println(name.toLowerCase());
		
		//get length 
		System.out.println(name.length());

		//replace
		System.out.println(name.replace("a", "xy"));
		
		//trim
		
		String ns = name.trim();
		System.out.println(ns);
		System.out.println(ns.length());
		
		//substring
		ns = name.substring(2,5);
		System.out.println(ns);

		//find location of char
		int ps = name.indexOf("m");
		System.out.println(ps);
		
		//find the char of given index
		System.out.println(name.charAt(2));
		
		
		//
		String n[] = name.split(" "); //n={"raman","sinha"}
		System.out.println(n[0]); //first name
		System.out.println(n[1]); //last name
		
		for(int i=0; i<n.length;i++) {
			System.out.println(n[i]);
		}
		
		
		//
		char cc[]= name.toCharArray();
		for(char c: cc) {
			System.out.println(c);
		}
		
		
		
		//conditional
		if(name.equals("RAMAN SINHA")) {
			System.out.println("MATCH");
		}else {
			System.out.println("is not match");
		}
		
		if(name.equalsIgnoreCase("RAMAN SINHA")) {
			System.out.println("match in ingore case");
		}
		else {
			System.out.println("not match in igonre case");
		}
		
		
		//
		if(name.contains("ma")) {
			System.out.println("ma is match");
		}else {
			System.out.println("ms is not match");
		}
		//start with
		if(name.startsWith("ra")) {
			System.out.println("start with ra");
		}else {
			System.out.println("not start with ra");
		}
		
		//ends with
		if(name.endsWith("ha")) {
			System.out.println("end with ha");
		}else {
			System.out.println("not end with ha");
		}
	}

}

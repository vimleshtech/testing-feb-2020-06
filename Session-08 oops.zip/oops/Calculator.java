package oops;

public class Calculator {

	public int a; //non-static member
	public static int b; //static member
	
	//non-static method
	public void add(int n1, int n2) {
		System.out.println(n1+n2);
	}
	
	//static function 
	public static void sub(int n1, int n2) {
		System.out.println(n1-n2);
	}
	
}

package oops;

import java.net.SocketTimeoutException;

public class Employee {

	//data member
	private int eid;
	private String name;
	private int sal;
	private double hra;
	private double other;
	private double msal;
	private double ysal;
	
	//read only variable
	final double tax=40; //assign the value when delcare the variable 
	

	//constructor 
	public Employee() {
			System.out.println("object is created !!!");
	}
	
	//parameterize constructor 
	public Employee(String country) {
		if(country.toUpperCase().equals("INDIA"))
		{
			System.out.println("Welcome to India ... All user are consided as Guest User");
		}
		else {
			System.out.println("welcome to other foreign country : All user are considered as NewUSer");
		}
	}

	//method
	public void input(int eid, String name, int sal) {
		this.eid = eid;  //this.eid  is global variable
		this.name = name;
		this.sal =sal;
	}
	public void compute() {
		this.hra = this.sal*.40;
		this.other = this.sal;
		this.msal = this.sal+this.hra+this.other;
		this.ysal = this.msal*12;
		
		System.out.println(this.ysal*this.tax/100); //print tax 
		
	}
	
	public void show() {
		
		System.out.println("---Employee Details ------");
		System.out.println("eid is "+this.eid);
		System.out.println("name is "+this.name);
		System.out.println("monthly sal is "+this.msal);
		System.out.println("yearly sal is "+this.ysal);
		
		
	}
	
}

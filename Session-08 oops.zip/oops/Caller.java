package oops;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e = new Employee();//create an object of class
		e.input(101, "Nitin", 34000);
		e.compute();
		e.show();
		//System.out.println(e.ysal); //private member cannot be accessed 
		
		//create new object with argument 
		Employee ee =new Employee("india");
		
				
		
	}

}

package oops;


public class StaticCaller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//access or call static vaiable or static method with class name
		Calculator.b=11;
		Calculator.sub(11, 44);
		
		//cannot be accessed
		//Calculator.a =11;
		//Calculator.add(11,4);
		
		//create an object to access non-static member 
		Calculator c1 =new Calculator();
		
		c1.a =11;
		c1.b =44;

		c1.add(11, 4);
		c1.add(114, 40);
		
		Calculator c2 =new Calculator();
		c2.a =110;
		c2.b =440;

		System.out.println(c1.a);//11
		System.out.println(c1.b);//440
		System.out.println(c2.a);//110
		System.out.println(c2.b);//440
	}

}


package filehandling;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create object
		Employee e = new Employee(); //Employee is class name
		//e is object 
		//new is keyword which allocate memory
		//Employee()   call to class constructor 
		
		e.newEmployee(); //call to function
		e.show();
		
	}

}

package filehandling;

import java.util.Scanner;

public class Employee {

	int eid;
	String name;
	int salary;
	
	void newEmployee() {
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter eid , name, salary");
		eid = sc.nextInt();
		name = sc.next();
		salary = sc.nextInt();
		
				
	}
	void show() {
		
		System.out.println("eid is "+eid);
		System.out.println("name is "+name);
		System.out.println("salary is "+salary);
		
	}
	
}

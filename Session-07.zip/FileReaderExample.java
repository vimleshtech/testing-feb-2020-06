package filehandling;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.SocketTimeoutException;

public class FileReaderExample {

	//
	public static void readFile() throws IOException  {
				
		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\testfile.txt");
		BufferedReader br = new BufferedReader(fr);
		
		//int n =br.read();
		String line = br.readLine();  //read first line 
		
		//get row count
		int rc=0;
		//get word count
		int wc=0;
		while(line !=null) {
			
			System.out.println(line);
			
			String word[]= line.split(" "); //convert sentence or line word 
			wc+= word.length; //get the length arary 
			
			line = br.readLine();
			rc+=1;
		}
		
		System.out.println("row count "+rc);
		System.out.println("word count "+wc);
		br.close();
		fr.close();
		
		
	}
	
	public static void writeFile() throws IOException {
		
		//overwrite the if exit, and new file if not exit 
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\testfile.txt",true); 
		//true : append in existing file
		//false: (default is false) overwirte the data 
		BufferedWriter bw = new BufferedWriter(fw);
		
		bw.write("hi, this is first file");
		bw.newLine();
		bw.write("bye");
		bw.newLine();
		
		bw.close();
		fw.close();
		
	}
	public static void main(String[] args) throws IOException {
	

		readFile();
		writeFile();
		readFile();
	}

}

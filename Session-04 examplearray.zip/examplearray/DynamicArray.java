package examplearray;

import java.util.Scanner;

public class DynamicArray {

	public static void main(String[] args) {
		
		int size;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter data  ");
		size = sc.nextInt();
		
		int x[] =new int[size];
		
		
		for(int i=0; i<size;i++) {
			System.out.println("entere data for array ");
			x[i] = sc.nextInt();
		}
		
		
		System.out.println("entere data ");
		for(int xy: x) {
			System.out.println(xy);
		}

	}

}

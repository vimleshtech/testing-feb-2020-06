package examplearray;

public class SingleDimenssion {

	public static void main(String[] args) {

		int x[] = {111,3,4,5,6,33334};
		
		System.out.println("count "+x.length); //return count of items 
		
		//print first value
		System.out.println(x[0]);
		System.out.println(x[1]); //print 2nd
		
		//loop: iterate data one by one
		for(int i=0; i<x.length;i++) {
			System.out.println("array data :"+x[i]);
		}
		
		//using forearch / advance loop
		// a ={33,55,666]
		// b = a // assign a to b
		// c : a //assign a to c one by one 
		//get sum of all values
		int s =0;
		for(int nd : x) {  //assign right to lect (x to nd one by one )
			System.out.println("using foreach :"+nd);
			s =s+nd;
		}
		System.out.println("total "+s);
		//also get the average
		System.out.println("avg = "+s/x.length);
		
		
		
	}

}
